package Final.src.snake;

public class SnakeDriver {

	public static void main(String[] args) {
		Snake snake = new Snake();
		snake.start();
	}

}
